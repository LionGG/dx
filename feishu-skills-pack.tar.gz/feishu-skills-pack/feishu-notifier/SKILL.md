# 飞书消息发送 Skill

## 功能
发送文字消息、图片、或图文混合消息到飞书群

## 文件位置
`~/.openclaw/workspace/stock/dx/scripts/feishu_notifier.py`

## 使用方法

### 1. 发送纯文字
```python
from feishu_notifier import send_to_feishu_group

send_to_feishu_group("消息内容")
```

### 2. 发送图片+文字
```python
from feishu_notifier import send_to_feishu_group

send_to_feishu_group("消息内容", "/path/to/image.png")
```

### 3. 只发送图片
```python
from feishu_notifier import upload_image, send_image_with_text

image_key = upload_image("/path/to/image.png")
if image_key:
    send_image_with_text(image_key, "")
```

## 函数说明

### send_to_feishu_group(text, image_path=None)
- **参数**：
  - text: 文字内容（必填）
  - image_path: 图片路径（可选）
- **返回**：True/False

### upload_image(image_path)
- **参数**：image_path: 图片路径
- **返回**：image_key 或 None

### send_image_with_text(image_key, text)
- **参数**：
  - image_key: 图片key
  - text: 文字内容
- **返回**：True/False

## 注意事项
1. 图片需要先上传获取image_key，再发送
2. 发送失败会打印错误信息
